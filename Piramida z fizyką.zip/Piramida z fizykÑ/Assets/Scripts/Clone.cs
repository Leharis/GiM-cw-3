﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Clone : MonoBehaviour {

    // Use this for initialization
    public GameObject prefab;

    void Start()
    {
        for (int i = 0; i < 10; i++)
            for (int j = 0; j < 10; j++)
            {
                Instantiate(prefab, new Vector3(j * 1.0f, i * 1.0f, 0), Quaternion.identity);
            }
            
    }
    // Update is called once per frame
    void Update () {
		
	}
}
